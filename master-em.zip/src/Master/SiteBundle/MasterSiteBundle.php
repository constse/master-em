<?php

namespace Master\SiteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MasterSiteBundle extends Bundle
{
} 