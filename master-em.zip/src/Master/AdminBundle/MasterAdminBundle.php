<?php

namespace Master\AdminBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MasterAdminBundle extends Bundle
{
} 