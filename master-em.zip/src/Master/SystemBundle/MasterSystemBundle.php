<?php

namespace Master\SystemBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MasterSystemBundle extends Bundle
{
} 